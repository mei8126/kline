package com.spinytech.macore.tools;

/**
 * Created by wanglei on 2016/12/27.
 */

public class RouterMessageUtil {
}
