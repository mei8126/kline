package com.spinytech.picdemo;

import com.spinytech.macore.router.LocalRouterConnectService;

/**
 * Created by wanglei on 2016/12/28.
 */

public class PicRouterConnectService extends LocalRouterConnectService {
}
