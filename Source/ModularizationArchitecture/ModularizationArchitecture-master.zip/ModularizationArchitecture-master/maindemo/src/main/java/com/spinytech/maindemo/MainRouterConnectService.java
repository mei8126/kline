package com.spinytech.maindemo;

import com.spinytech.macore.router.LocalRouterConnectService;

/**
 * Created by wanglei on 2016/12/28.
 */

public class MainRouterConnectService extends LocalRouterConnectService {
}
